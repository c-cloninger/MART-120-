function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  noStroke();
  fill(255,255,230);
  ellipse(200,200,250,350);
  
  fill(102,51,0);
  triangle(75,200,75,130,90,100);
  triangle(325,200,310,100,325,130);
  
  fill(255,102,102);
  circle(125,250,50);
  circle(275,250,50);
  
  stroke(102,0,51);
  strokeWeight(5);
  point(120,255);
  point(275,255);
  point(115,250);
  point(285,250);
  
  noStroke();
  fill(255,255,179);
  triangle(200,150,175,275,225,275);
  
  fill(179,143,0)
  arc(190,275,10,15,PI,0, OPEN);
  arc(210,275,10,15,PI,0, OPEN);
  
  stroke(0,0,0);
  strokeWeight(2);
  fill(0,204,153);
  ellipse(125,175,60,40);
  ellipse(275,175,60,40);
  
  fill(0,0,0);
  circle(125,175,20);
  circle(275,175,20);
  
  stroke(179,0,57);
  strokeWeight(3);
  fill(77,0,25);
  arc(200,300,100,75,0,PI, OPEN);
  
  stroke(89,89,89);
  noFill();
  arc(125,195,60,15,0,PI, OPEN);
  arc(275,195,60,15,0,PI, OPEN);
  
  stroke(102,51,0)
  strokeWeight(10)
  arc(125,160,75,25,PI,0, OPEN);
  arc(275,160,75,25,PI,0, OPEN);
  
  stroke(0,0,0);
  strokeWeight(2);
  line(95,175,65,150);
  line(95,175,65,175);
  line(95,175,65,162.5);
  line(305,175,335,150);
  line(305,175,335,175);
  line(305,175,335,162.5);
  
  noStroke();
  fill(102,51,0);
  arc(200,130,250,225,PI,0,CHORD);
  
  fill(0,0,0);
  rect(250,375,150,25,5);
  
  fill(242,242,242);
  text('Signed: Carrie Cloninger',260,390);
  
  fill(0,0,0);
  textSize(18);
  text('Self Portrait',150,17);
  
}

