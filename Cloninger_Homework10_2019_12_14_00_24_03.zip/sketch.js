var cheekRightX = 125;
var cheekLeftX = 275;
var cheekRightY = 250;
var cheekLeftY = 250;
var cheekDiam = 50;

var cheekRightMove = Math.floor(Math.random() * 10);
var cheekLeftMove = Math.floor(Math.random() * 10);

var pupilRightX = 125;
var pupilLeftX = 275;
var pupilRightY = 175;
var pupilLeftY = 175;
var pupilDiam = 20;

var pupilRightMove = Math.floor(Math.random() * 10);
var pupilLeftMove = Math.floor(Math.random() * 10);

var mouthX = 200
var mouthY = 300

var mouthMoveX = 10;
var mouthMoveY = 10;

var titleSize = 20;
var increaseSize = 1;
var i = 5;


function setup() {
  createCanvas(400,400);
}

function draw() {
  background(220);
  
  noStroke();
  fill(255,255,230);
  ellipse(200,200,250,350);
  
  fill(102,51,0);
  triangle(75,200,75,130,90,100);
  triangle(325,200,310,100,325,130);
  
  fill(255,102,102);
  circle(cheekRightX,cheekRightY,cheekDiam);
  circle(cheekLeftX,cheekLeftY,cheekDiam);
    if(cheekRightX >= 400 || cheekRightX <= 0){
      cheekRightMove*=-1;
    }
    cheekRightX += cheekRightMove;
  
    if(cheekLeftY >= 400 || cheekLeftY <= 0){
      cheekLeftMove*=-1;
    }
    cheekLeftY += cheekLeftMove;
  
  noStroke();
  fill(255,255,179);
  triangle(200,150,175,275,225,275);
  
  fill(179,143,0)
  arc(190,275,10,15,PI,0, OPEN);
  arc(210,275,10,15,PI,0, OPEN);
  
  stroke(0,0,0);
  strokeWeight(2);
  fill(0,204,153);
  ellipse(125,175,60,40);
  ellipse(275,175,60,40);
  
  fill(0,0,0);
  circle(pupilRightX,pupilRightY,pupilDiam);
  circle(pupilLeftX,pupilLeftY,pupilDiam);
  if(pupilRightY >= 400 || pupilRightY <= 0){
      pupilRightMove*=-1;
    }
  pupilRightY += pupilRightMove;
  
  if(pupilLeftX >= 400 || pupilLeftX <= 0){
      pupilLeftMove*=-1;
    }
  pupilLeftX += pupilLeftMove;
  
  
  stroke(179,0,57);
  strokeWeight(3);
  fill(77,0,25);
  arc(mouthX,mouthY,100,75,0,PI, OPEN);
    if((mouthX >= 400 && mouthY >=400) || (mouthX <= 0 && mouthY <=0)) {
      mouthMoveX*=-1;
      mouthMoveY*=-1;
    }
  
    mouthX+= mouthMoveX;
    mouthY+= mouthMoveY;
  
  stroke(89,89,89);
  noFill();
  arc(125,195,60,15,0,PI, OPEN);
  arc(275,195,60,15,0,PI, OPEN);
  
  stroke(102,51,0)
  strokeWeight(10)
  arc(125,160,75,25,PI,0, OPEN);
  arc(275,160,75,25,PI,0, OPEN);
  
  stroke(0,0,0);
  strokeWeight(2);
  line(95,175,65,150);
  line(95,175,65,175);
  line(95,175,65,162.5);
  line(305,175,335,150);
  line(305,175,335,175);
  line(305,175,335,162.5);
  
  noStroke();
  fill(102,51,0);
  arc(200,130,250,225,PI,0,CHORD);
  
  fill(0,0,0);
  rect(250,375,150,25,5);
  
  fill(242,242,242);
  textSize(12.5);
  text('Signed: Carrie Cloninger',325,380);
  
  
  fill(0,0,0);
  textSize(titleSize);
  textAlign(CENTER, TOP);
  text('Self Portrait',150,17,width);
  
  for(var i=0; i<=5; i++){
  if(titleSize <=40 || titleSize >= 0 ){
      increaseSize*=-1;
    }
  else{
    break;
  }
  }
    titleSize += increaseSize;

}

