var x = 100;
var y = 100;

var a = 200;
var b = 200;
var squareMoveX = Math.floor(Math.random() * 10);
var squareMoveY = Math.floor(Math.random() * 10);

var c = 100;
var d = 200;
var rectMoveX = Math.floor(Math.random() * 10);
var rectMoveY = Math.floor(Math.random() * 10);

var mousex = 0;
var mousey = 0;

function setup(){
  createCanvas(800,600);
}

function draw(){
  background(0);
  noStroke();
  
  fill(250,250,250);
  circle(x, y, 50);
  
  if(keyIsDown(68)){
    x+=5;
  }
  if(keyIsDown(65)){
    x-=5;
  }
  if(keyIsDown(83)){
    y+=5;
  }
  if(keyIsDown(87)){
    y-=5;
  }
  
  fill(255,0,102);
  square(a, b, 100);
  if(a >= 700 || a <= 0){
      squareMoveX*=-1;
    }
    a += squareMoveX;
  
  if(b >= 500 || b <= 0){
      squareMoveY*=-1;
    }
    b += squareMoveY;
  
  fill(102,102,155);
  rect(c, d, 100, 200);
  if(c >= 700 || c <= 0){
      rectMoveX*=-1;
    }
    c += rectMoveX;
  
  if(d >= 400 || d <= 0){
      rectMoveY*=-1;
    }
    d += rectMoveY;
  
  fill(255, 153, 102);
  circle(mousex, mousey, 75);
  
  fill(255, 255, 102);
  rect(300,550,250,50);
  fill(0,0,0);
  textSize(30);
  text('EXIT',390, 585);
  
  if(x > 300 && x < 550 && y > 550 && y < 600){
    fill(255, 255, 255);
    text('YOU WIN!',300,300);
  }

}

function mouseClicked(){
  mousex = mouseX;
  mousey = mouseY;
}